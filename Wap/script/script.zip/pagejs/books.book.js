﻿define(function (require, exports, module) {
    require("../pagejs/books");
});
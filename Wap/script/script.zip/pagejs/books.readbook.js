﻿define(function (require, exports, module) {
    require("../pagejs/books");
    require("/css/readbook.css");

    function switchCss(index) {

    }

    function zoomOut() {

    }
    function zoomIn() {

    }
});
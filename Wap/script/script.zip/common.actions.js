﻿define(function (require, exports, module) {
    var $ = require('lib/jquery.js');
    var DOM = {
        alertMessage: function(mssage,result,func) {

        }
    };
    return DOM;
});
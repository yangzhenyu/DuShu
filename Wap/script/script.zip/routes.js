﻿define({
    '/': '/pagejs/index',
    '/index.html': '/pagejs/index',
    '/demo.aspx': '/pagejs/index',
    '/search.aspx': 'pagejs/search',
    '/store.aspx': 'pagejs/store',
    '/user/login.aspx': 'pagejs/user.login',
    '/user/findpwd.aspx': 'pagejs/user.findpwd',
    '/books/book.aspx': 'pagejs/books.book',
    '/books/category.aspx': 'pagejs/books.category',
    '/books/chapter.aspx': 'pagejs/books.chapter',
    '/books/comment.aspx': 'pagejs/books.comment',
    '/books/readbook.aspx': 'pagejs/books.readbook'
});

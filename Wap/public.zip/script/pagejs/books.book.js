﻿define(function (require, exports, module) {
    require("../css/book.css");
});